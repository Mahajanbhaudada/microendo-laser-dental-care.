MICROENDO & LASER DENTAL CARE — WEBSITE

Included:
- Responsive single-page website with sections for Home, About, Treatments, Doctors, Gallery and Contact
- Clinic photos supplied by the user
- Call-to-clinic links, Google Maps directions, Instagram link and WhatsApp appointment enquiry
- Responsive mobile menu, gallery lightbox, basic form validation and SEO metadata

HOW TO PREVIEW:
1. Extract the ZIP file.
2. Open the microendo-dental-website folder.
3. Open index.html in a modern browser.

HOW TO PUBLISH FREE:
- Deploy the folder to a static hosting service such as Netlify or Cloudflare Pages.
- On Netlify, you can drag and drop the extracted folder (the folder containing index.html and assets) into the manual deploy area.
- Hosting providers can change their free-tier limits and account requirements.

IMPORTANT NOTES:
- The appointment form opens WhatsApp with a prefilled message. The visitor must press Send; no appointment is automatically confirmed.
- Google Maps is linked using the short link provided by the clinic. The exact street address and business hours were not provided, so they are not invented.
- Review the clinic's treatment list and doctor details before publishing. Remove any service that the clinic does not offer.
- For a custom domain, domain registration may cost money. A free hosting subdomain can be used instead.
